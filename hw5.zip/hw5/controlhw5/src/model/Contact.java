package model;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Contact {
    private String lastname;
    private String name;
    private String patronymic;
    private String phoneNumber;
    private String homePhoneNumber;
    private String address;
    private String birthday;
    private String notes;

    public Contact(String name, String lastname,String patronymic, String phoneNumber, String homePhoneNumber, String address, String birthday, String notes) {
        this.name = name;
        this.lastname = lastname;
        this.phoneNumber = phoneNumber;
        this.patronymic = patronymic;
        this.homePhoneNumber = homePhoneNumber;
        this.address = address;
        this.birthday = birthday;
        this.notes = notes;
    }
    public Contact(String name, String lastname, String phoneNumber){
        this.name = name;
        this.lastname = lastname;
        this.phoneNumber = phoneNumber;
    }
    public Contact(String stringContact){
        String[] args = stringContact.split(";");
        this.name = args[0];
        this.lastname = args[1];
        this.phoneNumber = args[2];
        this.patronymic = args[3];
        this.homePhoneNumber = args[4];
        this.address = args[5];
        this.birthday = args[6];
        this.notes = args[7];
    }
    //ПАРСЕР ИЗ СТРОКИ В ЦСВ И ТУСТРИНГ В ЦСВ
    public String getFullName(){
        return String.format("%s %s %s",getLastname(),getName(), getPatronymic());
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        if(lastname.equals("") ||lastname ==null){
            throw new IllegalArgumentException("Wrong argument for lastname of contact!");
        }
        this.lastname = lastname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(name.equals("") ||name ==null){
            throw new IllegalArgumentException("Wrong argument for name of contact!");
        }
        this.name = name;
    }

    public String getHomePhoneNumber() {
        return homePhoneNumber;
    }

    public void setHomePhoneNumber(String homePhoneNumber) {
        if(homePhoneNumber.equals("") ||homePhoneNumber ==null){
            throw new IllegalArgumentException("Wrong argument for homePhoneNumber of contact!");
        }
        this.homePhoneNumber = homePhoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }
}
