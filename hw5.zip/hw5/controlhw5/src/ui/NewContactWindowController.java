package ui;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TouchEvent;
import javafx.stage.Stage;
import model.Contact;
import util.PhoneBookApplication;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

public class NewContactWindowController {
    @FXML
    private TextField contactName;
    @FXML
    private TextField contactLastname;
    @FXML
    private TextField contactPatronymic;
    @FXML
    private DatePicker contactBirthday;
    @FXML
    private TextField contactNotes;
    @FXML
    private TextField contactPhoneNumber;
    @FXML
    private TextField contactHomePhoneNumber;
    @FXML
    private TextField contactAddress;
    @FXML
    private Button cancelButton;
    @FXML
    private Button saveButton;

    @FXML
    void initialize(){

    }

    @FXML
    private void onCancelClicked(){
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
    @FXML
    private  void onKeyPressed(){

    }
    @FXML
    private void onSaveClicked(){
        try {
            String name = contactName.textProperty().getValue();
            String lastname = contactLastname.textProperty().getValue();
            String patronymic = contactPatronymic.textProperty().getValue();
            String number = contactPhoneNumber.textProperty().getValue();
            String homeNumber = contactHomePhoneNumber.textProperty().getValue();
            String address = contactAddress.textProperty().getValue();
            String notes = contactNotes.textProperty().getValue();
            Date birthDate =
                    contactBirthday.getValue() != null ? java.sql.Date.valueOf(contactBirthday.getValue()) : null;
            String birthday = new SimpleDateFormat("dd MMM yyyy").format(birthDate);

            Contact newContact = new Contact(name, lastname, patronymic, number, homeNumber, address, birthday, notes);
            PhoneBookController.addContact(newContact);
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            stage.close();
        }catch (IllegalArgumentException e){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Непраильный аргумент!");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }catch (NullPointerException e){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning alert");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }
    @FXML
    private void onPhoneTextFieldTapped(MouseEvent event){
        String number = contactPhoneNumber.textProperty().getValue();
        String[] numberParts = number.split("-");
        if(numberParts.length!=5){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning alert");
            alert.setContentText("Неправильно набран номер");
            alert.showAndWait();
        }
    }
    @FXML
    private void fixName(){
        String name = contactName.textProperty().getValue();
        String lastname = contactLastname.textProperty().getValue();
        if(!name.equals("") ||name!=null){
            name = name.toLowerCase(Locale.ROOT);
            name= String.valueOf(name.charAt(0)).toUpperCase()+name.substring(0,name.length());

            contactName.textProperty().setValue(name);
        }
    }

}
