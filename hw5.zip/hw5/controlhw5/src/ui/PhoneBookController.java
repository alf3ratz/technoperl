package ui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Contact;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PhoneBookController {
    private static ObservableList<Contact> contacts;
    private FilteredList<Contact> filteredContacts;
    //private ObservableList<Contact> shownContacts;
    private MenuBar menuBar;
    @FXML
    private TextField searchTextField;
    @FXML
    private  TableView<Contact> table;
    @FXML
    private TableColumn<Contact, String> nameColumn;
    @FXML
    private TableColumn<Contact, String> lastnameColumn;
    @FXML
    private TableColumn<Contact, String> patronymicColumn;
    @FXML
    private TableColumn<Contact, String> phoneNumberColumn;
    @FXML
    private TableColumn<Contact, String> homePhoneNumberColumn;
    @FXML
    private TableColumn<Contact, String> notesColumn;
    @FXML
    private TableColumn<Contact, String> birthdayColumn;
    @FXML
    private TableColumn<Contact, String> addressColumn;
    @FXML
    private Button deleteButton;
    @FXML
    private Button redactButton;
    @FXML
    private Button searchButton;
    @FXML
    private Button addButton;

    @FXML
    private void initialize() {
        contacts = FXCollections.observableArrayList();
        filteredContacts = new FilteredList<>(contacts,b->true);
        //shownContacts = FXCollections.observableArrayList();
        searchTextField.setFocusTraversable(false);
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        lastnameColumn.setCellValueFactory(new PropertyValueFactory<>("lastname"));
        patronymicColumn.setCellValueFactory(new PropertyValueFactory<>("patronymic"));
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        homePhoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("homePhoneNumber"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        birthdayColumn.setCellValueFactory(new PropertyValueFactory<>("birthday"));
        notesColumn.setCellValueFactory(new PropertyValueFactory<>("notes"));
    }

    private void makeAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Непраильный аргумент!");

        // alert.setHeaderText("Results:");
        alert.setContentText(msg);

        alert.showAndWait();
    }

    @FXML
    private void onSearchClicked() {
        String text = searchTextField.getText();
        //List<Contact> lst = filter(text);
       // table.setItems((ObservableList<Contact>) shownContacts);
        searchTextField.textProperty().addListener((observable,oldValue,newValue)->{
            filteredContacts.setPredicate(contact->{
                if(newValue==null || newValue.isEmpty())
                    return true;
                String filteredText = newValue.toLowerCase();
                if(contact.getName().toLowerCase().contains(filteredText)){
                    return true;
                }else if(contact.getLastname().toLowerCase().contains(filteredText)){
                    return true;
                }else if(contact.getPatronymic().toLowerCase().contains(filteredText)){
                    return true;
                }else{
                    return false;
                }
            });
        });
        SortedList<Contact> sortedContacts = new SortedList<>(filteredContacts);
        sortedContacts.comparatorProperty().bind(table.comparatorProperty());
        table.setItems(sortedContacts);
    }

    private void refreshTable() {
        table.getItems().clear();
        table.getItems().addAll(contacts);
        // table.setItems((ObservableList<Contact>) contacts);
    }

    @FXML
    private void addContactWindow() {
        Stage newContactStage = new Stage();
        try {
            FXMLLoader root = new FXMLLoader(NewContactWindowController.class.getResource("/new_contact_window.fxml"));
            Parent rootPane = root.load();
            ((NewContactWindowController) root.getController()).initialize();
            newContactStage.setScene(new Scene(rootPane));
            newContactStage.setTitle("Добавить контакст");
            newContactStage.initModality(Modality.APPLICATION_MODAL);
            newContactStage.setResizable(false);
            newContactStage.showAndWait();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (RuntimeException e) {
            makeAlert(e.getMessage());
        }
        refreshTable();
    }

//    public static void addContact(Contact newContact) {
//        try {
//            contacts.add(newContact);
//            refreshTable(newContact);
//        } catch (IllegalArgumentException e) {
//            System.out.println(e.getMessage());
//        }
//    }

    public void redactContact(String fullName, Contact newContact) {
        // Проверка?
        contacts.stream().filter(n -> {
            if (n.getFullName().equals(fullName))
                n = newContact;
            return false;
        });
    }
    public static void addContact(Contact newContact){
        contacts.add(newContact);
    }

    public List<Contact> filter(String fullName) {
        List<Contact> selectedContacts = new ArrayList<>();
        contacts.forEach(contact -> {
            //contact.getFullName().equals(fullName)
            if (contact.getFullName().contains(fullName))
                selectedContacts.add(contact);
        });
        return selectedContacts;
    }
    public void onDeleteContact(){

    }

    public void removeContact(Contact contact) {
        contacts.removeIf((p) -> {
            return p.getFullName().equals(contact.getFullName());
        });
    }

    public void readCsv(String path) {
        BufferedReader reader;
        String row;
        try {
            reader = new BufferedReader(new FileReader(path));
            reader.readLine();
            while ((row = reader.readLine()) != null) {
                Contact contact = new Contact(row);
            }
            reader.close();
        } catch (IOException e) {
            throw new RuntimeException("Sth happened while reading csv...\n" + e.getMessage());
        }
    }

    public void writeCsv(String path, boolean all) {
        try {
            FileWriter writer = new FileWriter(path);
            writer.append("lastname;name;patronymic");
            writer.append(";phoneNumber;homePhoneNumber");
            writer.append(";address;birthday;notes");
            if (all) {
                for (var cont : contacts) {
                    writer.append("\n");
                    writer.append(cont.toString());
                }
            } else {
                for (var cont : filteredContacts/*shownContacts*/) {
                    writer.append("\n");
                    writer.append(cont.toString());
                }
            }
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
