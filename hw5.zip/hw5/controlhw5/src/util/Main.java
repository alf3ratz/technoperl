package util;

import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(PhoneBookApplication.class, args);
    }
}
