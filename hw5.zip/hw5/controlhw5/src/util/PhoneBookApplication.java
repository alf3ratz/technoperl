package util;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;
import model.Contact;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PhoneBookApplication extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/sample.fxml"));
        primaryStage.setTitle("Phone Book");

        primaryStage.setScene(new Scene(root));
//        menuBar = new MenuBar();
//
//        // Create the File menu.
//        makeFileMenu();
//        root.set
//        root.setTop(menuBar);
        primaryStage.setResizable(false);
        primaryStage.show();


    }



}
